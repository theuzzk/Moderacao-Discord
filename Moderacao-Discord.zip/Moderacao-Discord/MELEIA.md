# Discord bot

Listed by Syntax.gg

https://discord.gg/6x7t2qxrVf

PS: We don't own none of these scripts, we're just a discord community.

Sig;
Syntax.gg staff.
